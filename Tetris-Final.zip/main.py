import pygame
import sys
import random

mainClock = pygame.time.Clock()

pygame.init()
pygame.display.set_caption('Just do it! Tetris')
screen = pygame.display.set_mode((1000,2000), 0, 32)

font = pygame.font.SysFont(None, 20)


def draw_text(text, font, color, surface, x, y):
    textobj = font.render(text, 1, color)
    textrect = textobj.get_rect()
    textrect.topleft = (x, y)
    surface.blit(textobj, textrect)


def main_menu():
    click = False
    while True:

        screen.fill((0, 0, 0))
        draw_text('main menu   (Highly Recommend to Read the How To Play)',
                  font, (255, 255, 255), screen, 20, 20)

        mx, my = pygame.mouse.get_pos()

        button_1 = pygame.Rect(50, 100, 200, 50)

        button_2 = pygame.Rect(50, 200, 200, 50)
        if button_1.collidepoint((mx, my)):
            if click:
                game()
        if button_2.collidepoint((mx, my)):
            if click:
                options()
        pygame.draw.rect(screen, (255, 0, 0), button_1)
        pygame.draw.rect(screen, (255, 0, 0), button_2)

        click = False
        for event in pygame.event.get():
            if event.type == pygame.K_z:
                pygame.quit()
                sys.exit()
            if event.type == pygame.K_c:
                if event.key == pygame.K_x:
                    pygame.quit()
                    sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:
                    click = True
        draw_text("Play", font, (255, 255, 255), screen, 100, 120)
        draw_text("How to Play", font, (255, 255, 255), screen, 100, 220)
        pygame.display.update()
        mainClock.tick(60)


def game():
    running = True
    while running:

        colors = [
            (0, 0, 0),
            (120, 37, 179),
            (100, 179, 179),
            (80, 34, 22),
            (80, 134, 22),
            (180, 34, 22),
            (180, 34, 122),
        ]

        class Figure:
            x = 0
            y = 0
            #Creating the Figure
            figures = [
                [[1, 5, 9, 13], [4, 5, 6, 7]],
                [[4, 5, 9, 10], [2, 6, 5, 9]],
                [[6, 7, 9, 10], [1, 5, 6, 10]],
                [[1, 2, 5, 9], [0, 4, 5, 6], [1, 5, 9, 8], [4, 5, 6, 10]],
                [[1, 2, 6, 10], [5, 6, 7, 9], [2, 6, 10, 11], [3, 5, 6, 7]],
                [[1, 4, 5, 6], [1, 4, 5, 9], [4, 5, 6, 9], [1, 5, 6, 9]],
                [[1, 2, 5, 6]],
            ]

            def __init__(self, x, y):
                self.x = x
                self.y = y
                self.type = random.randint(0, len(self.figures) - 1)
                self.color = random.randint(1, len(colors) - 1)
                self.rotation = 0

            def image(self):
                return self.figures[self.type][self.rotation]

            def rotate(self):
                self.rotation = (self.rotation + 1) % len(
                    self.figures[self.type])

        class Tetris:
            level = 2
            score = 0
            state = "start"
            field = []
            height = 0
            width = 0
            x = 100
            y = 60
            zoom = 20
            figure = None

            def __init__(self, height, width):
                self.height = height
                self.width = width
                self.field = []
                self.score = 0
                self.state = "start"
                for i in range(height):
                    new_line = []
                    for j in range(width):
                        new_line.append(0)
                    self.field.append(new_line)

            def new_figure(self):
                self.figure = Figure(3, 0)

            def intersects(self):
                intersection = False
                for i in range(4):
                    for j in range(4):
                        if i * 4 + j in self.figure.image():
                            if i + self.figure.y > self.height - 1 or \
                                    j + self.figure.x > self.width - 1 or \
                                    j + self.figure.x < 0 or \
                                    self.field[i + self.figure.y][j + self.figure.x] > 0:
                                intersection = True
                return intersection

            def break_lines(self):
                lines = 0
                for i in range(1, self.height):
                    zeros = 0
                    for j in range(self.width):
                        if self.field[i][j] == 0:
                            zeros += 1
                    if zeros == 0:
                        lines += 1
                        for i1 in range(i, 1, -1):
                            for j in range(self.width):
                                self.field[i1][j] = self.field[i1 - 1][j]
                self.score += lines**5

            def go_space(self):
                while not self.intersects():
                    self.figure.y += 1
                self.figure.y -= 1
                self.freeze()

            def go_down(self):
                if figurew > 20:
                    self.figure.y += 2
                else:
                    self.figure.y += 1
                if self.intersects():
                    self.figure.y -= 1
                    if self.intersects():
                        self.figure.y -= 1
                    self.freeze()

            def freeze(self):
                for i in range(4):
                    for j in range(4):
                        if i * 4 + j in self.figure.image():
                            self.field[i + self.figure.y][
                                j + self.figure.x] = self.figure.color
                self.break_lines()
                self.new_figure()
                if self.intersects():
                    self.state = "gameover"

            def go_side(self, dx):
                old_x = self.figure.x
                self.figure.x += dx
                if self.intersects():
                    self.figure.x = old_x

            def rotate(self):
                old_rotation = self.figure.rotation
                self.figure.rotate()
                if self.intersects():
                    self.figure.rotation = old_rotation

        pygame.init()
        # Define some colors
        BLACK = (0, 0, 0)
        WHITE = (255, 255, 255)
        GRAY = (128, 128, 128)

        size = (400, 500)
        screen = pygame.display.set_mode(size)

        pygame.display.set_caption("Tetris")

        # Loop until the user clicks the close button.
        done = False
        clock = pygame.time.Clock()
        fps = 25
        figurew = 0
        game = Tetris(20, 10)
        counter = 0

        pressing_down = False

        while not done:
            if game.figure is None:
                game.new_figure()
            counter += 1
            if counter > 100000:
                counter = 0

            if counter % (fps // game.level // 2) == 0 or pressing_down:
                if game.state == "start":
                    game.go_down()
            for event in pygame.event.get():
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_UP:
                        game.rotate()
                    if event.key == pygame.K_DOWN:
                        pressing_down = True
                    if event.key == pygame.K_LEFT:
                        game.go_side(-1)
                        figurew += 1
                        print(figurew)
                    if event.key == pygame.K_RIGHT:
                        game.go_side(1)
                    if event.key == pygame.K_SPACE:
                        game.go_space()
                    if event.key == pygame.K_1:
                        game.__init__(20, 10)
                        figurew = 0
                    if event.key == pygame.K_t:
                        running = False
                        main_menu()
                        pygame.quit()
                        sys.exit()
                    if event.key == pygame.K_p:
                        pause()

            if event.type == pygame.KEYUP:
                if event.key == pygame.K_DOWN:
                    pressing_down = False

            screen.fill(WHITE)

            for i in range(game.height):
                for j in range(game.width):
                    pygame.draw.rect(screen, GRAY, [
                        game.x + game.zoom * j, game.y + game.zoom * i,
                        game.zoom, game.zoom
                    ], 1)
                    if game.field[i][j] > 0:
                        pygame.draw.rect(screen, colors[game.field[i][j]], [
                            game.x + game.zoom * j + 1, game.y +
                            game.zoom * i + 1, game.zoom - 2, game.zoom - 1
                        ])

            if game.figure is not None:
                for i in range(4):
                    for j in range(4):
                        p = i * 4 + j
                        if p in game.figure.image():
                            pygame.draw.rect(screen, colors[game.figure.color],
                                             [
                                                 game.x + game.zoom *
                                                 (j + game.figure.x) + 1,
                                                 game.y + game.zoom *
                                                 (i + game.figure.y) + 1,
                                                 game.zoom - 2, game.zoom - 2
                                             ])

            font = pygame.font.SysFont('Calibri', 25, True, False)
            font1 = pygame.font.SysFont('Calibri', 65, True, False)
            text = font.render("Score: " + str(game.score), True, BLACK)
            text_game_over = font1.render("Game Over", True, (255, 125, 0))
            text_game_over1 = font1.render("Press 1 ", True, (255, 215, 0))
            screen.blit(text, [0, 0])
            if game.state == "gameover":
                screen.blit(text_game_over, [20, 200])
                screen.blit(text_game_over1, [25, 265])
            pygame.display.flip()
            clock.tick(fps)

        mainClock.tick(60)
        pygame.quit()
        pygame.display.update()


def pause():
    pause = True
    while pause:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                quit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_c:
                    pause = False
                elif event.key == pygame.K_8:
                    game()

        font1 = pygame.font.SysFont('Calibri', 30, True, False)
        text_game_over = font1.render("Press C to Continue ", True,
                                      (255, 125, 0))
        text_game_over1 = font1.render(" Press 8 to Reset", True,
                                       (125, 125, 125))
        screen.blit(text_game_over, [20, 200])
        screen.blit(text_game_over1, [20, 265])
        pygame.display.update()
        mainClock.tick(5)


def options():
    running = True
    while running:
        screen.fill((0, 0, 0))

        draw_text(
            "The aim in Tetris is simple; you bring down blocks from the top of the screen",
            font, (255, 255, 255), screen, 10, 20)

        draw_text(
            " You can move the blocks around, either left(left arrow key) to right(right arrow key)",
            font, (255, 255, 255), screen, 10, 50)

        draw_text(
            " key) and/or you can rotate(up arrow key) them. The blocks fall at a certain rate,",
            font, (255, 255, 255), screen, 10, 80)
     
        draw_text(
            "but you can make them fall faster(space or down arrow key) if you're sure of your positioning",
            font, (255, 255, 255), screen, 10, 110)

        draw_text("If you not sure positioning athen you can clear blocks by 1", font, (255, 255, 255),
                  screen, 10, 140)

        draw_text("Press P to pause the game then continue (Press C)", font,
                  (255, 255, 255), screen, 10, 170)

        draw_text("After pausing the game, press 8 to totally reset", font,
                  (255, 255, 255), screen, 10, 200)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    running = False

        pygame.display.update()
        mainClock.tick(60)


main_menu()
